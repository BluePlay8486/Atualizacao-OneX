# downloader.py
import xbmc
import xbmcgui
import xbmcvfs
import six
from six.moves import urllib_request
import hashlib

LOGINFO = xbmc.LOGNOTICE if six.PY2 else xbmc.LOGINFO

def download(url, dest, proxy=None, headers=None, expected_hash=None):
    dp = xbmcgui.DialogProgress()
    dp.create("BluePlay", "Iniciando download...")

    try:
        xbmc.log(f"[BluePlay Downloader] Download: {url}", LOGINFO)

        # Configura requisição com headers
        request_headers = headers or {}
        req = urllib_request.Request(url, headers=request_headers)

        if proxy:
            proxy_handler = urllib_request.ProxyHandler({'http': proxy, 'https': proxy})
            opener = urllib_request.build_opener(proxy_handler)
            response = opener.open(req, timeout=10)
        else:
            response = urllib_request.urlopen(req, timeout=10)

        total_size = response.getheader('Content-Length')
        total_size = int(total_size.strip()) if total_size else 0
        bytes_so_far = 0

        sha256 = hashlib.sha256() if expected_hash else None

        with xbmcvfs.File(dest, 'w+b') as out_file:
            while True:
                chunk = response.read(1024 * 32)
                if not chunk:
                    break
                out_file.write(chunk)
                bytes_so_far += len(chunk)
                if sha256:
                    sha256.update(chunk)

                percent = int((bytes_so_far * 100) / total_size) if total_size else 0
                mensagem = f"{int(bytes_so_far/1024)} KB de {int(total_size/1024)} KB" if total_size else f"{int(bytes_so_far/1024)} KB baixados"
                dp.update(percent, mensagem)

                if dp.iscanceled():
                    dp.close()
                    xbmcvfs.delete(dest)
                    raise Exception("Download cancelado pelo usuário.")

        dp.update(100, "Download concluído.")
        dp.close()

        if expected_hash:
            hash_result = sha256.hexdigest()
            if hash_result.lower() != expected_hash.lower():
                xbmcvfs.delete(dest)
                raise Exception(f"Hash inválido. Esperado: {expected_hash}, Recebido: {hash_result}")

        xbmc.log("[BluePlay Downloader] Download concluído com sucesso.", LOGINFO)

    except Exception as e:
        dp.close()
        if xbmcvfs.exists(dest):
            xbmcvfs.delete(dest)
        xbmc.log(f"[BluePlay Downloader] ERRO: {str(e)}", xbmc.LOGERROR)
        raise Exception(f"Erro no download: {str(e)}")