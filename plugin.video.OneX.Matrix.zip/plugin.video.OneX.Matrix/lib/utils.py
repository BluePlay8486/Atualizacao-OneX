# -*- coding: utf-8 -*-
import sys
import urllib.parse
import inspect

_routes = {}

def route(path):
    def decorator(func):
        _routes[path] = func
        return func
    return decorator

def run():
    try:
        plugin_url = sys.argv[0]
        plugin_handle = int(sys.argv[1])
        query = sys.argv[2][1:] if len(sys.argv) > 2 else ''
        params = dict(urllib.parse.parse_qsl(query))
        path = urllib.parse.urlparse(plugin_url).path

        for route_path, func in _routes.items():
            if plugin_url.endswith(route_path):
                # Passar parâmetros da URL
                func(params)
                return True
        return False
    except Exception as e:
        import xbmc
        xbmc.log(f'Erro no router: {e}', xbmc.LOGERROR)
        return False
